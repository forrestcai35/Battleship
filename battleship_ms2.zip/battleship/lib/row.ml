(*open Cell

  type row_t = cell_t list

  let rec create_row size x y : row_t = if size > 0 then create_cell x y ::
  create_row (size - 1) (x + 1) y else []

  let rec create_grid curr_col cols rows = if curr_col < cols then create_row
  cols 0 curr_col :: create_grid (curr_col + 1) cols rows else [] *)
