type cell_t = {
  occupied : bool;
  hit : bool;
  x : int;
  y : int;
}

let update_occupied x y cell =
  if cell.x = x && cell.y = y then { cell with occupied = true } else cell

let update_hit x y cell =
  if cell.x = x && cell.y = y then { cell with hit = true } else cell

let print_cell_debug cell =
  print_endline
    ("cell coords : " ^ string_of_int cell.x ^ ", " ^ string_of_int cell.y
   ^ " | " ^ "occupied: "
    ^ string_of_bool cell.occupied
    ^ " | " ^ "hit : " ^ string_of_bool cell.hit)

let print_cell cell = if cell.occupied = true then "x" else "o"

let create_cell x_input y_input =
  { occupied = false; hit = false; x = x_input; y = y_input }
