open Cell
(* open Row *)

type grid_t = cell_t list list

let init_grid =
  [
    [ create_cell 0 0; create_cell 1 0; create_cell 2 0; create_cell 3 0 ];
    [ create_cell 0 1; create_cell 1 1; create_cell 2 1; create_cell 3 1 ];
    [ create_cell 0 2; create_cell 1 2; create_cell 2 2; create_cell 3 2 ];
    [ create_cell 0 3; create_cell 1 3; create_cell 2 3; create_cell 3 3 ];
  ]

(* let rec create_grid curr_col cols rows = if curr_col < cols then create_row
   cols 0 curr_col :: create_grid (curr_col + 1) cols rows else [] *)

let add_ship x y grid =
  List.map (List.map (fun cell -> update_occupied x y cell)) grid

let update_hit x y grid =
  List.map (List.map (fun cell -> update_hit x y cell)) grid

let rec get_cell_row row x =
  match row with
  | [] -> failwith "empty row"
  | cell :: t -> if cell.x = x then cell else get_cell_row t x

let rec get_cell2 x y cur_row (grid : grid_t) =
  match grid with
  | [] -> failwith "empty grid"
  | row :: t ->
      if cur_row = y then get_cell_row row x else get_cell2 x y (cur_row + 1) t

let rec print_row (row : cell_t list) =
  match row with
  | [] -> ""
  | cell :: row_t -> print_cell cell ^ " | " ^ print_row row_t

let print_grid (grid : grid_t) =
  List.iter (fun row -> print_endline (print_row row)) grid
